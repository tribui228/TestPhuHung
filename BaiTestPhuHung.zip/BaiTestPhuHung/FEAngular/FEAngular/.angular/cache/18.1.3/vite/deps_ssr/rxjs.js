import { createRequire } from 'module';const require = createRequire(import.meta.url);
import {
  require_cjs
} from "./chunk-5PGU7M6N.js";
import "./chunk-LED6VGVJ.js";
export default require_cjs();
//# sourceMappingURL=rxjs.js.map
